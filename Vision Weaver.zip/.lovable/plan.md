## Plan: ElevenLabs integration

### 1. Secret
- Add `ELEVENLABS_API_KEY` via the secrets tool (user pastes from elevenlabs.io → Profile → API Keys).

### 2. Replace audio generation backend
- Rewrite `src/routes/api/generate-audio.ts` (currently Gemini-based) to call ElevenLabs Music API:
  - `POST https://api.elevenlabs.io/v1/music` with `{ prompt, music_length_ms }`
  - Header `xi-api-key: $ELEVENLABS_API_KEY`
  - Return raw MP3 bytes (`Content-Type: audio/mpeg`), no base64.
- Keep input validation (Zod): `prompt` string, optional `durationSeconds` (clamp 10–120s → ms).

### 3. Client wiring
- `AudioPicker.tsx` already posts to `/api/generate-audio` and confirms generation — switch fetch to use `response.blob()` → object URL instead of base64 data URI.
- Playback alongside animatic (existing `playback.ts` + orange playhead) stays unchanged.

### 4. Voice agent prep (no UI yet)
- Just leave a note in plan.md that ElevenLabs Conversational AI will reuse the same `ELEVENLABS_API_KEY` when voice mode is built. No code yet — out of scope for this turn.

### Files to touch
- `src/routes/api/generate-audio.ts` — rewrite for ElevenLabs Music
- `src/components/workspace/AudioPicker.tsx` — blob handling
- `.lovable/plan.md` — note voice agent future use

After you approve, I'll request the `ELEVENLABS_API_KEY` secret and implement.
